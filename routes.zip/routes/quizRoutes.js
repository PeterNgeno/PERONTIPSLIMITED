const express = require('express');
const quizController = require('../controllers/quizController');
const paymentController = require('../controllers/paymentController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', authMiddleware, quizController.getQuizPage);
router.post('/submit', authMiddleware, quizController.submitQuiz);
router.post('/pay', authMiddleware, paymentController.processPayment);

module.exports = router;
